package com.haweli.hisab

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.hisab.data.HaweliRepository
import com.haweli.hisab.model.*
import com.haweli.hisab.ui.HaweliViewModel
import com.haweli.hisab.util.ReportExporter

// कलर पैलेट (Modern Royal Green & Gold/Warm Neutral Theme for HAWELI)
val HaweliPrimary = Color(0xFF1B4332)
val HaweliSecondary = Color(0xFF2D6A4F)
val AanaCardGreen = Color(0xFF1E6043)
val DenaCardRed = Color(0xFF9B2226)
val BgSurface = Color(0xFFF6F8F5)

enum class BottomNavTab(val titleHindi: String) {
    HOME("डैशबोर्ड"),
    PARTIES("सभी पार्टियां"),
    OFFICE("ऑफिस (अप्सर भाई)"),
    REPORTS("महीने का हिसाब"),
    SETTINGS("सेटिंग / एडमिन")
}

class MainActivity : ComponentActivity() {
    private val viewModel: HaweliViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = HaweliPrimary,
                    secondary = HaweliSecondary,
                    background = BgSurface
                )
            ) {
                HaweliMainApp(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HaweliMainApp(viewModel: HaweliViewModel) {
    val parties by viewModel.parties.collectAsState()
    val entries by viewModel.ledgerEntries.collectAsState()
    val officeEntries by viewModel.officeEntries.collectAsState()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsState()
    val isLocked by viewModel.isFirebaseLocked.collectAsState()
    val selectedCity by viewModel.selectedCityFilter.collectAsState()

    var currentTab by remember { mutableStateOf(BottomNavTab.HOME) }
    var selectedPartyForDetail by remember { mutableStateOf<Party?>(null) }

    val summaries = remember(parties, entries) {
        viewModel.computeAllPartySummaries(parties, entries)
    }

    // कुल आना (Aana) और कुल देना (Dena) की लाइव गणना
    val totalAana = remember(summaries) {
        summaries.filter { it.party.direction == HisabDirection.AANA.name }
            .sumOf { it.netClosingBalance.coerceAtLeast(0.0) }
    }
    val totalDena = remember(summaries) {
        summaries.filter { it.party.direction == HisabDirection.DENA.name }
            .sumOf { it.netClosingBalance.coerceAtLeast(0.0) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "HAWELI (हवेली हिसाब-किताब)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 19.sp,
                            color = Color.White
                        )
                        Text(
                            text = if (isAdmin) "मोड: एडमिन (Edit/Delete सक्रिय)" else "मोड: सामान्य यूजर (केवल देखने व नई एंट्री हेतु)",
                            fontSize = 11.sp,
                            color = Color(0xFFD8F3DC)
                        )
                    }
                },
                actions = {
                    if (isAdmin) {
                        AssistChip(
                            onClick = { currentTab = BottomNavTab.SETTINGS },
                            label = { Text("एडमिन सक्रिय", color = Color.White, fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF95D5B2))
                            },
                            colors = AssistChipDefaults.assistChipColors(containerColor = HaweliSecondary)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = HaweliPrimary)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                NavigationBarItem(
                    selected = currentTab == BottomNavTab.HOME && selectedPartyForDetail == null,
                    onClick = {
                        selectedPartyForDetail = null
                        currentTab = BottomNavTab.HOME
                    },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                    label = { Text("डैशबोर्ड", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = currentTab == BottomNavTab.PARTIES || selectedPartyForDetail != null,
                    onClick = {
                        selectedPartyForDetail = null
                        currentTab = BottomNavTab.PARTIES
                    },
                    icon = { Icon(Icons.Default.Groups, contentDescription = null) },
                    label = { Text("पार्टियां", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = currentTab == BottomNavTab.OFFICE,
                    onClick = {
                        selectedPartyForDetail = null
                        currentTab = BottomNavTab.OFFICE
                    },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = null) },
                    label = { Text("ऑफिस", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = currentTab == BottomNavTab.REPORTS,
                    onClick = {
                        selectedPartyForDetail = null
                        currentTab = BottomNavTab.REPORTS
                    },
                    icon = { Icon(Icons.Default.Assessment, contentDescription = null) },
                    label = { Text("रिपोर्ट", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = currentTab == BottomNavTab.SETTINGS,
                    onClick = {
                        selectedPartyForDetail = null
                        currentTab = BottomNavTab.SETTINGS
                    },
                    icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = null) },
                    label = { Text("सेटिंग", fontSize = 11.sp) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BgSurface)
                .padding(innerPadding)
        ) {
            if (selectedPartyForDetail != null) {
                val latestParty = parties.find { it.id == selectedPartyForDetail!!.id } ?: selectedPartyForDetail!!
                PartyDetailLedgerScreen(
                    party = latestParty,
                    summary = viewModel.computePartySummary(latestParty, entries),
                    entries = entries.filter { it.partyId == latestParty.id },
                    isAdmin = isAdmin,
                    isFirebaseLocked = isLocked,
                    onBack = { selectedPartyForDetail = null },
                    onSaveEntry = { entry -> viewModel.repository.addOrUpdateLedgerEntry(entry, isAdmin) },
                    onDeleteEntry = { entryId -> viewModel.repository.deleteLedgerEntry(entryId, isAdmin) }
                )
            } else {
                when (currentTab) {
                    BottomNavTab.HOME -> CleanDashboardScreen(
                        totalAana = totalAana,
                        totalDena = totalDena,
                        summaries = summaries,
                        onSelectParty = { selectedPartyForDetail = it },
                        onNavigateTab = { currentTab = it }
                    )
                    BottomNavTab.PARTIES -> PartiesManagementScreen(
                        summaries = summaries,
                        selectedCity = selectedCity,
                        onSelectCity = { viewModel.setCityFilter(it) },
                        isAdmin = isAdmin,
                        isFirebaseLocked = isLocked,
                        onOpenParty = { selectedPartyForDetail = it },
                        onSaveParty = { party -> viewModel.repository.addOrUpdateParty(party, isAdmin) },
                        onDeleteParty = { partyId -> viewModel.repository.deleteParty(partyId, isAdmin) }
                    )
                    BottomNavTab.OFFICE -> OfficeApsarBhaiScreen(
                        officeEntries = officeEntries,
                        isAdmin = isAdmin,
                        isFirebaseLocked = isLocked,
                        onSaveOfficeEntry = { viewModel.repository.addOrUpdateOfficeEntry(it, isAdmin) },
                        onDeleteOfficeEntry = { viewModel.repository.deleteOfficeEntry(it, isAdmin) }
                    )
                    BottomNavTab.REPORTS -> MonthlyReportScreen(
                        totalAana = totalAana,
                        totalDena = totalDena,
                        summaries = summaries,
                        entries = entries,
                        officeEntries = officeEntries
                    )
                    BottomNavTab.SETTINGS -> AdminAndSettingsScreen(
                        isAdmin = isAdmin,
                        isFirebaseLocked = isLocked,
                        onAdminLogin = { u, p -> viewModel.loginAsAdmin(u, p) },
                        onAdminLogout = { viewModel.logoutAdmin() },
                        onToggleLock = { locked -> viewModel.repository.setFirebaseLock(locked, isAdmin) }
                    )
                }
            }
        }
    }
}

/**
 * STRICT UI RULE #3: CLEAN HEADER DASHBOARD
 * ऐप खोलने पर होमपेज के हेडर/डैशबोर्ड में केवल दो बड़े मुख्य कार्ड दिखते हैं:
 * 1. पहला कार्ड: कुल आना (Aana)
 * 2. दूसरा कार्ड: कुल देना (Dena)
 * बाकी सारे विकल्प नीचे नेविगेशन बार और त्वरित सूची में व्यवस्थित हैं।
 */
@Composable
fun CleanDashboardScreen(
    totalAana: Double,
    totalDena: Double,
    summaries: List<PartyBalanceSummary>,
    onSelectParty: (Party) -> Unit,
    onNavigateTab: (BottomNavTab) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // CLEAN HEADER: ONLY TWO LARGE MAIN CARDS (कुल आना & कुल देना)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // पहला बड़ा मुख्य कार्ड: कुल आना (Aana)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateTab(BottomNavTab.PARTIES) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = AanaCardGreen),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "कुल आना (Aana)",
                                color = Color(0xFFD8F3DC),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDownward,
                                contentDescription = "कुल आना",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = ReportExporter.formatInr(totalAana),
                            color = Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "मार्केट से कुल लेने योग्य बकाया राशि",
                            color = Color(0xFFB7E4C7),
                            fontSize = 12.sp
                        )
                    }
                }

                // दूसरा बड़ा मुख्य कार्ड: कुल देना (Dena)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateTab(BottomNavTab.PARTIES) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DenaCardRed),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "कुल देना (Dena)",
                                color = Color(0xFFFFCCD5),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowUpward,
                                contentDescription = "कुल देना",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = ReportExporter.formatInr(totalDena),
                            color = Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "व्यापारियों/पार्टियों को कुल देने योग्य राशि",
                            color = Color(0xFFFFB3C1),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // शहर के अनुसार त्वरित सारांश पट्टी
        item {
            Text(
                text = "शहर के अनुसार पार्टियों का हिसाब",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = HaweliPrimary
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CityCategory.entries.forEach { city ->
                    val count = summaries.count { it.party.city == city.hindiName }
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateTab(BottomNavTab.PARTIES) },
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White,
                        tonalElevation = 2.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = city.hindiName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = "$count पार्टी", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }

        // प्रमुख पार्टियों की हालिया स्थिति
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "पार्टियों की खाता सूची",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = HaweliPrimary
                )
                TextButton(onClick = { onNavigateTab(BottomNavTab.PARTIES) }) {
                    Text("सभी देखें / जोड़ें →")
                }
            }
        }

        if (summaries.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("अभी कोई पार्टी नहीं जोड़ी गई है।", fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(onClick = { onNavigateTab(BottomNavTab.PARTIES) }) {
                            Text("नई पार्टी जोड़ें")
                        }
                    }
                }
            }
        } else {
            items(summaries) { item ->
                PartySummaryRowCard(
                    summary = item,
                    isAdmin = false, // डैशबोर्ड पर केवल क्लिक करके खाता खोलें
                    onClick = { onSelectParty(item.party) },
                    onEdit = {},
                    onDelete = {}
                )
            }
        }
    }
}

/**
 * सभी पार्टियां (City-Wise Party Management: बारामती, भूम, धाराशिव, अन्य शहर)
 * Normal user: पार्टी जोड़ सकता है और देख सकता है।
 * Admin user: पार्टी को Edit और Delete भी कर सकता है।
 */
@Composable
fun PartiesManagementScreen(
    summaries: List<PartyBalanceSummary>,
    selectedCity: String,
    onSelectCity: (String) -> Unit,
    isAdmin: Boolean,
    isFirebaseLocked: Boolean,
    onOpenParty: (Party) -> Unit,
    onSaveParty: (Party) -> Boolean,
    onDeleteParty: (String) -> Boolean
) {
    val context = LocalContext.current
    var showPartyDialog by remember { mutableStateOf(false) }
    var editingParty by remember { mutableStateOf<Party?>(null) }
    var selectedDirectionFilter by remember { mutableStateOf("ALL") } // ALL, AANA, DENA

    val cityOptions = listOf("सभी शहर") + CityCategory.entries.map { it.hindiName }

    val filteredSummaries = summaries.filter { s ->
        val matchesCity = selectedCity == "सभी शहर" || s.party.city == selectedCity
        val matchesDir = selectedDirectionFilter == "ALL" || s.party.direction == selectedDirectionFilter
        matchesCity && matchesDir
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (isFirebaseLocked && !isAdmin) {
                        Toast.makeText(context, "डेटाबेस लॉक है! कृपया एडमिन से संपर्क करें।", Toast.LENGTH_SHORT).show()
                    } else {
                        editingParty = null
                        showPartyDialog = true
                    }
                },
                containerColor = HaweliPrimary,
                contentColor = Color.White
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("नई पार्टी जोड़ें")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(14.dp)
        ) {
            // शहर फ़िल्टर (बारामती, भूम, धाराशिव, अन्य शहर)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(cityOptions) { city ->
                    FilterChip(
                        selected = selectedCity == city,
                        onClick = { onSelectCity(city) },
                        label = { Text(city) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // आना / देना फ़िल्टर
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = selectedDirectionFilter == "ALL",
                    onClick = { selectedDirectionFilter = "ALL" },
                    label = { Text("सभी खाते") }
                )
                FilterChip(
                    selected = selectedDirectionFilter == HisabDirection.AANA.name,
                    onClick = { selectedDirectionFilter = HisabDirection.AANA.name },
                    label = { Text("आना (Aana)") }
                )
                FilterChip(
                    selected = selectedDirectionFilter == HisabDirection.DENA.name,
                    onClick = { selectedDirectionFilter = HisabDirection.DENA.name },
                    label = { Text("देना (Dena)") }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (filteredSummaries.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("इस श्रेणी में कोई पार्टी उपलब्ध नहीं है।", color = Color.Gray)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filteredSummaries) { summary ->
                        PartySummaryRowCard(
                            summary = summary,
                            isAdmin = isAdmin, // STRICT RULE: केवल एडमिन को Edit/Delete दिखेगा
                            onClick = { onOpenParty(summary.party) },
                            onEdit = {
                                editingParty = summary.party
                                showPartyDialog = true
                            },
                            onDelete = {
                                onDeleteParty(summary.party.id)
                                Toast.makeText(context, "पार्टी हटाई गई", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }

    if (showPartyDialog) {
        AddOrEditPartyDialog(
            initialParty = editingParty,
            onDismiss = { showPartyDialog = false },
            onConfirm = { party ->
                val ok = onSaveParty(party)
                if (!ok) {
                    Toast.makeText(context, "केवल एडमिन ही पार्टी एडिट कर सकता है!", Toast.LENGTH_SHORT).show()
                }
                showPartyDialog = false
            }
        )
    }
}

@Composable
fun PartySummaryRowCard(
    summary: PartyBalanceSummary,
    isAdmin: Boolean,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isAana = summary.party.direction == HisabDirection.AANA.name
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = summary.party.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "शहर: ${summary.party.city} • ${if (isAana) "आना (लेना)" else "देना (बकाया)"}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = ReportExporter.formatInr(summary.netClosingBalance),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = if (isAana) AanaCardGreen else DenaCardRed
                    )
                    Text(
                        text = "कुल बाकी",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = Color(0xFFEEEEEE))
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("पुरानी बाकी: ${ReportExporter.formatInr(summary.oldBalance)}", fontSize = 11.sp, color = Color.DarkGray)
                Text("नया बिल: ${ReportExporter.formatInr(summary.newBillTotal)}", fontSize = 11.sp, color = Color.DarkGray)
                Text("जमा: ${ReportExporter.formatInr(summary.totalPayments)}", fontSize = 11.sp, color = AanaCardGreen)
            }

            // STRICT RULE #1: Edit & Delete buttons ONLY visible when Admin is logged in
            if (isAdmin) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "एडिट", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("एडिट करें", fontSize = 12.sp)
                    }
                    TextButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.textButtonColors(contentColor = DenaCardRed)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "डिलीट", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("डिलीट करें", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AddOrEditPartyDialog(
    initialParty: Party?,
    onDismiss: () -> Unit,
    onConfirm: (Party) -> Unit
) {
    var name by remember { mutableStateOf(initialParty?.name ?: "") }
    var phone by remember { mutableStateOf(initialParty?.phone ?: "") }
    var selectedCity by remember { mutableStateOf(initialParty?.city ?: CityCategory.BARAMATI.hindiName) }
    var direction by remember { mutableStateOf(initialParty?.direction ?: HisabDirection.AANA.name) }
    var openingBalance by remember { mutableStateOf(initialParty?.openingBalance?.toString() ?: "0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialParty == null) "नई पार्टी जोड़ें" else "पार्टी विवरण एडिट करें") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("पार्टी का नाम *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("मोबाइल नंबर") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("शहर चुनें:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(CityCategory.entries) { city ->
                        FilterChip(
                            selected = selectedCity == city.hindiName,
                            onClick = { selectedCity = city.hindiName },
                            label = { Text(city.hindiName) }
                        )
                    }
                }

                Text("हिसाब का प्रकार:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = direction == HisabDirection.AANA.name,
                        onClick = { direction = HisabDirection.AANA.name },
                        label = { Text("आना (लेना है)") }
                    )
                    FilterChip(
                        selected = direction == HisabDirection.DENA.name,
                        onClick = { direction = HisabDirection.DENA.name },
                        label = { Text("देना (बकाया देय)") }
                    )
                }

                OutlinedTextField(
                    value = openingBalance,
                    onValueChange = { openingBalance = it },
                    label = { Text("पुरानी बाकी (Opening Balance ₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(
                            Party(
                                id = initialParty?.id ?: "",
                                name = name.trim(),
                                phone = phone.trim(),
                                city = selectedCity,
                                direction = direction,
                                openingBalance = openingBalance.toDoubleOrNull() ?: 0.0
                            )
                        )
                    }
                }
            ) {
                Text("सेव करें")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("रद्द करें") }
        }
    )
}

/**
 * पार्टी का विस्तृत खाता (Party Detail Screen):
 * 1. बड़े जानवरों का हिसाब (संख्या, कुल वजन KG, प्रति KG रेट = कुल रकम)
 * 2. Veal माल का हिसाब
 * 3. अलग-अलग तारीखों पर भुगतान (Payment) की एंट्री
 * 4. पुरानी बाकी + नया बिल - जमा = कुल बाकी
 * 5. Edit और Delete बटन केवल Admin लॉगिन होने पर दिखेंगे।
 */
@Composable
fun PartyDetailLedgerScreen(
    party: Party,
    summary: PartyBalanceSummary,
    entries: List<LedgerEntry>,
    isAdmin: Boolean,
    isFirebaseLocked: Boolean,
    onBack: () -> Unit,
    onSaveEntry: (LedgerEntry) -> Boolean,
    onDeleteEntry: (String) -> Boolean
) {
    val context = LocalContext.current
    var showEntryDialog by remember { mutableStateOf(false) }
    var dialogDefaultType by remember { mutableStateOf(EntryType.BIG_ANIMAL) }
    var editingEntry by remember { mutableStateOf<LedgerEntry?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        // पार्टी हेडर
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "वापस")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(party.name, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Text(
                    "शहर: ${party.city} • विभाग: ${if (party.direction == HisabDirection.AANA.name) "आना (Aana)" else "देना (Dena)"}",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // पुरानी बाकी + नया बिल - भुगतान = कुल बाकी कार्ड
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = HaweliPrimary),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("पुरानी बाकी", color = Color(0xFFB7E4C7), fontSize = 11.sp)
                        Text(ReportExporter.formatInr(summary.oldBalance), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("नया बिल (जानवर + Veal)", color = Color(0xFFB7E4C7), fontSize = 11.sp)
                        Text(ReportExporter.formatInr(summary.newBillTotal), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("कुल जमा/भुगतान", color = Color(0xFFB7E4C7), fontSize = 11.sp)
                        Text(ReportExporter.formatInr(summary.totalPayments), color = Color(0xFF95D5B2), fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = HaweliSecondary)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("कुल नेट बाकी (Closing Balance):", color = Color.White, fontSize = 14.sp)
                    Text(
                        text = ReportExporter.formatInr(summary.netClosingBalance),
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // त्वरित एंट्री बटन: बड़े जानवर | Veal माल | भुगतान (Payment)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    if (isFirebaseLocked && !isAdmin) {
                        Toast.makeText(context, "डेटाबेस लॉक है!", Toast.LENGTH_SHORT).show()
                    } else {
                        editingEntry = null
                        dialogDefaultType = EntryType.BIG_ANIMAL
                        showEntryDialog = true
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = HaweliPrimary)
            ) {
                Text("+ बड़े जानवर", fontSize = 12.sp)
            }
            Button(
                onClick = {
                    if (isFirebaseLocked && !isAdmin) {
                        Toast.makeText(context, "डेटाबेस लॉक है!", Toast.LENGTH_SHORT).show()
                    } else {
                        editingEntry = null
                        dialogDefaultType = EntryType.VEAL_GOODS
                        showEntryDialog = true
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = HaweliSecondary)
            ) {
                Text("+ Veal माल", fontSize = 12.sp)
            }
            Button(
                onClick = {
                    if (isFirebaseLocked && !isAdmin) {
                        Toast.makeText(context, "डेटाबेस लॉक है!", Toast.LENGTH_SHORT).show()
                    } else {
                        editingEntry = null
                        dialogDefaultType = EntryType.PAYMENT
                        showEntryDialog = true
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0077B6))
            ) {
                Text("+ पेमेंट जमा", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("खाता प्रविष्टियां (तारीख वार):", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(6.dp))

        if (entries.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("इस पार्टी में अभी कोई एंट्री नहीं है। ऊपर दिए गए बटन से जोड़ें।", color = Color.Gray)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(entries) { entry ->
                    LedgerEntryRowCard(
                        entry = entry,
                        isAdmin = isAdmin,
                        onEdit = {
                            editingEntry = entry
                            showEntryDialog = true
                        },
                        onDelete = {
                            onDeleteEntry(entry.id)
                            Toast.makeText(context, "एंट्री डिलीट की गई", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    if (showEntryDialog) {
        AddOrEditLedgerEntryDialog(
            party = party,
            defaultType = dialogDefaultType,
            initialEntry = editingEntry,
            onDismiss = { showEntryDialog = false },
            onConfirm = { entry ->
                onSaveEntry(entry)
                showEntryDialog = false
            }
        )
    }
}

@Composable
fun LedgerEntryRowCard(
    entry: LedgerEntry,
    isAdmin: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val typeEnum = EntryType.entries.find { it.name == entry.entryType } ?: EntryType.BIG_ANIMAL
    val isPayment = typeEnum == EntryType.PAYMENT

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPayment) Color(0xFFE8F5E9) else Color.White
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${typeEnum.hindiTitle} • तारीख: ${entry.dateString}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isPayment) AanaCardGreen else HaweliPrimary
                )
                Text(
                    text = ReportExporter.formatInr(entry.totalAmount),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = if (isPayment) AanaCardGreen else DenaCardRed
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            when (typeEnum) {
                EntryType.BIG_ANIMAL -> {
                    Text(
                        text = "जानवर संख्या: ${entry.animalCount} | कुल वजन: ${entry.totalWeightKg} KG × ₹${entry.ratePerKg}/KG = ${ReportExporter.formatInr(entry.totalAmount)}",
                        fontSize = 13.sp,
                        color = Color.DarkGray
                    )
                }
                EntryType.VEAL_GOODS -> {
                    Text(
                        text = "Veal माल विवरण: ${entry.itemDescription.ifBlank { "Veal माल बिल" }}",
                        fontSize = 13.sp,
                        color = Color.DarkGray
                    )
                }
                EntryType.PAYMENT -> {
                    Text(
                        text = "भुगतान माध्यम: ${entry.paymentMode} ${if (entry.notes.isNotBlank()) "• ${entry.notes}" else ""}",
                        fontSize = 13.sp,
                        color = Color.DarkGray
                    )
                }
                EntryType.OLD_BALANCE -> {
                    Text(
                        text = "पुरानी बाकी समायोजन: ${entry.notes}",
                        fontSize = 13.sp,
                        color = Color.DarkGray
                    )
                }
            }

            // STRICT RULE #1: केवल Admin लॉगिन होने पर ही Edit और Delete बटन दिखेंगे
            if (isAdmin) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("एडिट", fontSize = 12.sp)
                    }
                    TextButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.textButtonColors(contentColor = DenaCardRed)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("डिलीट", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AddOrEditLedgerEntryDialog(
    party: Party,
    defaultType: EntryType,
    initialEntry: LedgerEntry?,
    onDismiss: () -> Unit,
    onConfirm: (LedgerEntry) -> Unit
) {
    var selectedType by remember {
        mutableStateOf(
            initialEntry?.let { e -> EntryType.entries.find { it.name == e.entryType } } ?: defaultType
        )
    }
    var dateString by remember { mutableStateOf(initialEntry?.dateString ?: HaweliRepository.todayDateString()) }
    var animalCount by remember { mutableStateOf(initialEntry?.animalCount?.toString() ?: "") }
    var totalWeightKg by remember { mutableStateOf(initialEntry?.totalWeightKg?.toString() ?: "") }
    var ratePerKg by remember { mutableStateOf(initialEntry?.ratePerKg?.toString() ?: "") }
    var itemDescription by remember { mutableStateOf(initialEntry?.itemDescription ?: "") }
    var manualAmount by remember { mutableStateOf(initialEntry?.totalAmount?.toString() ?: "") }
    var paymentMode by remember { mutableStateOf(initialEntry?.paymentMode ?: "नकद (Cash)") }
    var notes by remember { mutableStateOf(initialEntry?.notes ?: "") }

    // ऑटोमैटिक कैलकुलेशन: कुल वजन KG × प्रति KG रेट = कुल रकम
    val weightVal = totalWeightKg.toDoubleOrNull() ?: 0.0
    val rateVal = ratePerKg.toDoubleOrNull() ?: 0.0
    val autoAnimalTotal = weightVal * rateVal

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialEntry == null) "${party.name} - नई एंट्री" else "एंट्री एडिट करें") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("एंट्री का प्रकार:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf(EntryType.BIG_ANIMAL, EntryType.VEAL_GOODS, EntryType.PAYMENT)) { t ->
                        FilterChip(
                            selected = selectedType == t,
                            onClick = { selectedType = t },
                            label = { Text(t.hindiTitle) }
                        )
                    }
                }

                OutlinedTextField(
                    value = dateString,
                    onValueChange = { dateString = it },
                    label = { Text("तारीख (DD-MM-YYYY)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                when (selectedType) {
                    EntryType.BIG_ANIMAL -> {
                        OutlinedTextField(
                            value = animalCount,
                            onValueChange = { animalCount = it },
                            label = { Text("जानवरों की संख्या (Count)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = totalWeightKg,
                            onValueChange = { totalWeightKg = it },
                            label = { Text("कुल वजन (KG)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = ratePerKg,
                            onValueChange = { ratePerKg = it },
                            label = { Text("प्रति KG रेट (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Surface(
                            color = Color(0xFFE8F5E9),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "कुल रकम (वजन × रेट): ${ReportExporter.formatInr(autoAnimalTotal)}",
                                modifier = Modifier.padding(10.dp),
                                fontWeight = FontWeight.Bold,
                                color = AanaCardGreen
                            )
                        }
                    }

                    EntryType.VEAL_GOODS -> {
                        OutlinedTextField(
                            value = itemDescription,
                            onValueChange = { itemDescription = it },
                            label = { Text("Veal माल का विवरण (वजन / नग / क्वालिटी)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = manualAmount,
                            onValueChange = { manualAmount = it },
                            label = { Text("Veal माल की कुल रकम (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    EntryType.PAYMENT -> {
                        OutlinedTextField(
                            value = manualAmount,
                            onValueChange = { manualAmount = it },
                            label = { Text("भुगतान (Payment) की रकम (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = paymentMode,
                            onValueChange = { paymentMode = it },
                            label = { Text("भुगतान का माध्यम (नकद / बैंक / UPI)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    EntryType.OLD_BALANCE -> {}
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("नोट / टिप्पणी (वैकल्पिक)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalAmount = if (selectedType == EntryType.BIG_ANIMAL) {
                        autoAnimalTotal
                    } else {
                        manualAmount.toDoubleOrNull() ?: 0.0
                    }
                    if (finalAmount > 0.0) {
                        onConfirm(
                            LedgerEntry(
                                id = initialEntry?.id ?: "",
                                partyId = party.id,
                                partyName = party.name,
                                city = party.city,
                                direction = party.direction,
                                entryType = selectedType.name,
                                dateString = dateString.trim(),
                                timestamp = initialEntry?.timestamp ?: System.currentTimeMillis(),
                                animalCount = animalCount.toIntOrNull() ?: 0,
                                totalWeightKg = weightVal,
                                ratePerKg = rateVal,
                                itemDescription = itemDescription.trim(),
                                totalAmount = finalAmount,
                                paymentMode = paymentMode.trim(),
                                notes = notes.trim()
                            )
                        )
                    }
                }
            ) {
                Text("सेव करें")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("रद्द करें") }
        }
    )
}

/**
 * ऑफिस सेक्शन (अप्सर भाई का हिसाब):
 * - पैसे दिए (Given) और पैसे लिए (Received) का पूरा हिसाब
 * - नेट बैलेंस कैलकुलेशन
 * - केवल एडमिन को ही Edit/Delete का अधिकार
 */
@Composable
fun OfficeApsarBhaiScreen(
    officeEntries: List<OfficeEntry>,
    isAdmin: Boolean,
    isFirebaseLocked: Boolean,
    onSaveOfficeEntry: (OfficeEntry) -> Boolean,
    onDeleteOfficeEntry: (String) -> Boolean
) {
    val context = LocalContext.current
    var showDialog by remember { mutableStateOf(false) }
    var editingOfficeEntry by remember { mutableStateOf<OfficeEntry?>(null) }

    val totalGiven = officeEntries.filter { it.transactionType == "GIVEN" }.sumOf { it.amount }
    val totalReceived = officeEntries.filter { it.transactionType == "RECEIVED" }.sumOf { it.amount }
    val netBalance = totalGiven - totalReceived

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (isFirebaseLocked && !isAdmin) {
                        Toast.makeText(context, "डेटाबेस लॉक है!", Toast.LENGTH_SHORT).show()
                    } else {
                        editingOfficeEntry = null
                        showDialog = true
                    }
                },
                containerColor = HaweliPrimary,
                contentColor = Color.White
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ऑफिस एंट्री जोड़ें")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(14.dp)
        ) {
            Text(
                text = "ऑफिस सेक्शन - अप्सर भाई हिसाब",
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
                color = HaweliPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = HaweliPrimary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("कुल पैसे दिए", color = Color(0xFFB7E4C7), fontSize = 12.sp)
                            Text(
                                ReportExporter.formatInr(totalGiven),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("कुल पैसे लिए", color = Color(0xFFB7E4C7), fontSize = 12.sp)
                            Text(
                                ReportExporter.formatInr(totalReceived),
                                color = Color(0xFF95D5B2),
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = HaweliSecondary)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("नेट ऑफिस बैलेंस (अप्सर भाई):", color = Color.White, fontSize = 14.sp)
                        Text(
                            text = ReportExporter.formatInr(netBalance),
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 22.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (officeEntries.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("ऑफिस (अप्सर भाई) में अभी कोई एंट्री नहीं है।", color = Color.Gray)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(officeEntries) { item ->
                        val isGiven = item.transactionType == "GIVEN"
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${if (isGiven) "पैसे दिए" else "पैसे लिए"} • ${item.dateString}",
                                        fontWeight = FontWeight.Bold,
                                        color = if (isGiven) DenaCardRed else AanaCardGreen
                                    )
                                    Text(
                                        text = ReportExporter.formatInr(item.amount),
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isGiven) DenaCardRed else AanaCardGreen
                                    )
                                }
                                if (item.remark.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("विवरण: ${item.remark}", fontSize = 13.sp, color = Color.DarkGray)
                                }

                                // STRICT RULE #1: केवल Admin ही ऑफिस एंट्री को Edit या Delete कर सकता है
                                if (isAdmin) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        TextButton(onClick = {
                                            editingOfficeEntry = item
                                            showDialog = true
                                        }) {
                                            Text("एडिट", fontSize = 12.sp)
                                        }
                                        TextButton(
                                            onClick = { onDeleteOfficeEntry(item.id) },
                                            colors = ButtonDefaults.textButtonColors(contentColor = DenaCardRed)
                                        ) {
                                            Text("डिलीट", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        var txType by remember { mutableStateOf(editingOfficeEntry?.transactionType ?: "GIVEN") }
        var amount by remember { mutableStateOf(editingOfficeEntry?.amount?.toString() ?: "") }
        var dateStr by remember { mutableStateOf(editingOfficeEntry?.dateString ?: HaweliRepository.todayDateString()) }
        var remark by remember { mutableStateOf(editingOfficeEntry?.remark ?: "") }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(if (editingOfficeEntry == null) "अप्सर भाई (ऑफिस) नई एंट्री" else "ऑफिस एंट्री एडिट करें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = txType == "GIVEN",
                            onClick = { txType = "GIVEN" },
                            label = { Text("पैसे दिए (Given)") }
                        )
                        FilterChip(
                            selected = txType == "RECEIVED",
                            onClick = { txType = "RECEIVED" },
                            label = { Text("पैसे लिए (Received)") }
                        )
                    }
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text("रकम (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = dateStr,
                        onValueChange = { dateStr = it },
                        label = { Text("तारीख (DD-MM-YYYY)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = remark,
                        onValueChange = { remark = it },
                        label = { Text("विवरण / किस काम के लिए") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val amt = amount.toDoubleOrNull() ?: 0.0
                    if (amt > 0.0) {
                        onSaveOfficeEntry(
                            OfficeEntry(
                                id = editingOfficeEntry?.id ?: "",
                                personName = "अप्सर भाई (ऑफिस)",
                                transactionType = txType,
                                amount = amt,
                                dateString = dateStr.trim(),
                                timestamp = editingOfficeEntry?.timestamp ?: System.currentTimeMillis(),
                                remark = remark.trim()
                            )
                        )
                        showDialog = false
                    }
                }) {
                    Text("सेव करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("रद्द करें") }
            }
        )
    }
}

/**
 * महीने का हिसाब और हिस्ट्री (Monthly Report & History):
 * - तारीख / महीने के अनुसार फ़िल्टर
 * - पुरानी बाकी और नए बिल का सही हिसाब
 * - एक क्लिक में PDF और Excel (CSV) में डाउनलोड व शेयर करने की सुविधा
 */
@Composable
fun MonthlyReportScreen(
    totalAana: Double,
    totalDena: Double,
    summaries: List<PartyBalanceSummary>,
    entries: List<LedgerEntry>,
    officeEntries: List<OfficeEntry>
) {
    val context = LocalContext.current
    var dateQuery by remember { mutableStateOf("") } // उदा. 11-2026 या विशेष तारीख

    val filteredEntries = remember(entries, dateQuery) {
        if (dateQuery.isBlank()) entries
        else entries.filter { it.dateString.contains(dateQuery.trim(), ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        Text(
            text = "महीने का हिसाब और रिपोर्ट (PDF / Excel)",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = HaweliPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = dateQuery,
            onValueChange = { dateQuery = it },
            label = { Text("तारीख या महीना खोजें (उदा. 11-2026 या 09-11-2026)") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    ReportExporter.exportMonthlyPdfReport(
                        context = context,
                        filterTitle = dateQuery.ifBlank { "संपूर्ण मासिक रिपोर्ट" },
                        totalAana = totalAana,
                        totalDena = totalDena,
                        partySummaries = summaries,
                        entries = filteredEntries,
                        officeEntries = officeEntries
                    )
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = DenaCardRed)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("PDF डाउनलोड")
            }

            Button(
                onClick = {
                    ReportExporter.exportMonthlyExcelCsvReport(
                        context = context,
                        partySummaries = summaries,
                        entries = filteredEntries,
                        officeEntries = officeEntries
                    )
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = AanaCardGreen)
            ) {
                Icon(Icons.Default.TableView, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Excel डाउनलोड")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "पार्टी वार हिसाब (पुरानी बाकी + नया बिल - भुगतान = कुल बाकी)",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(summaries) { s ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${s.party.name} (${s.party.city})", fontWeight = FontWeight.Bold)
                            Text(
                                text = "कुल बाकी: ${ReportExporter.formatInr(s.netClosingBalance)}",
                                fontWeight = FontWeight.ExtraBold,
                                color = if (s.party.direction == HisabDirection.AANA.name) AanaCardGreen else DenaCardRed
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "पुरानी बाकी: ${ReportExporter.formatInr(s.oldBalance)} | नया बिल: ${ReportExporter.formatInr(s.newBillTotal)} | कुल जमा: ${ReportExporter.formatInr(s.totalPayments)}",
                            fontSize = 12.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }
        }
    }
}

/**
 * एडमिन लॉगिन और Firebase Settings Lock Screen:
 * STRICT RULE #2: Admin credentials APK में कहीं भी प्रदर्शित या हिंट नहीं किए गए हैं।
 */
@Composable
fun AdminAndSettingsScreen(
    isAdmin: Boolean,
    isFirebaseLocked: Boolean,
    onAdminLogin: (String, String) -> Boolean,
    onAdminLogout: () -> Unit,
    onToggleLock: (Boolean) -> Unit
) {
    val context = LocalContext.current
    var usernameInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "एडमिन कंट्रोल एवं सुरक्षा सेटिंग्स",
            fontWeight = FontWeight.Bold,
            fontSize = 19.sp,
            color = HaweliPrimary
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!isAdmin) {
                    Text(
                        text = "एडमिन लॉगिन (Edit / Delete अधिकार के लिए)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "नोट: सामान्य यूजर किसी भी एंट्री, पार्टी या पेमेंट को एडिट या डिलीट नहीं कर सकता। एडिट और डिलीट बटन सक्रिय करने के लिए एडमिन लॉगिन करें।",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = { usernameInput = it },
                        label = { Text("एडमिन यूज़रनेम दर्ज करें") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("एडमिन पासवर्ड दर्ज करें") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            val ok = onAdminLogin(usernameInput, passwordInput)
                            if (ok) {
                                usernameInput = ""
                                passwordInput = ""
                                Toast.makeText(context, "एडमिन लॉगिन सफल! Edit और Delete बटन सक्रिय हो गए हैं।", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "गलत यूज़रनेम या पासवर्ड!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = HaweliPrimary)
                    ) {
                        Icon(Icons.Default.LockOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("एडमिन लॉगिन करें")
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("एडमिन मोड सक्रिय है", fontWeight = FontWeight.Bold, color = AanaCardGreen, fontSize = 17.sp)
                            Text("आप सभी पार्टियों व प्रविष्टियों को Edit और Delete कर सकते हैं।", fontSize = 12.sp, color = Color.DarkGray)
                        }
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = AanaCardGreen)
                    }

                    Divider()

                    // Firebase Settings Lock System
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Firebase Settings Lock System", fontWeight = FontWeight.Bold)
                            Text(
                                "इसे ऑन करने पर सामान्य यूजर नई एंट्री भी नहीं जोड़ सकेंगे (केवल रीड-ओनली मोड)।",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        Switch(
                            checked = isFirebaseLocked,
                            onCheckedChange = { onToggleLock(it) }
                        )
                    }

                    Button(
                        onClick = {
                            onAdminLogout()
                            Toast.makeText(context, "एडमिन लॉगआउट हो गया (सामान्य यूजर मोड सक्रिय)", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DenaCardRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("एडमिन लॉगआउट करें")
                    }
                }
            }
        }
    }
}
