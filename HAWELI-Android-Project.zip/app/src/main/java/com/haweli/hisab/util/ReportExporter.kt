package com.haweli.hisab.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import com.haweli.hisab.model.EntryType
import com.haweli.hisab.model.HisabDirection
import com.haweli.hisab.model.LedgerEntry
import com.haweli.hisab.model.OfficeEntry
import com.haweli.hisab.model.PartyBalanceSummary
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Locale

/**
 * महीने का हिसाब, पार्टी खाता और ऑफिस (अप्सर भाई) की रिपोर्ट
 * PDF और Excel (.csv UTF-8 BOM) में तैयार करने और शेयर/डाउनलोड करने की सुविधा।
 */
object ReportExporter {

    private val inrFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    fun formatInr(amount: Double): String = inrFormat.format(amount)

    /**
     * मासिक एवं पार्टी हिसाब की PDF फाइल बनाकर शेयर/ओपन करता है
     */
    fun exportMonthlyPdfReport(
        context: Context,
        filterTitle: String,
        totalAana: Double,
        totalDena: Double,
        partySummaries: List<PartyBalanceSummary>,
        entries: List<LedgerEntry>,
        officeEntries: List<OfficeEntry>
    ) {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 size
            val page = pdfDocument.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.rgb(27, 67, 50)
                textSize = 20f
                isFakeBoldText = true
            }
            val subHeaderPaint = Paint().apply {
                color = Color.rgb(45, 106, 79)
                textSize = 14f
                isFakeBoldText = true
            }
            val bodyPaint = Paint().apply {
                color = Color.BLACK
                textSize = 11f
            }
            val linePaint = Paint().apply {
                color = Color.LTGRAY
                strokeWidth = 1f
            }

            var y = 45f
            canvas.drawText("HAWELI (हवेली) - व्यापार हिसाब-किताब रिपोर्ट", 35f, y, titlePaint)
            y += 22f
            canvas.drawText("रिपोर्ट अवधि / फ़िल्टर: $filterTitle", 35f, y, subHeaderPaint)
            y += 15f
            canvas.drawLine(35f, y, 560f, y, linePaint)

            // मुख्य कार्ड सारांश (कुल आना और कुल देना)
            y += 25f
            canvas.drawText("कुल आना (लेना है): ${formatInr(totalAana)}", 35f, y, subHeaderPaint)
            canvas.drawText("कुल देना (देना है): ${formatInr(totalDena)}", 300f, y, subHeaderPaint)
            y += 18f
            canvas.drawLine(35f, y, 560f, y, linePaint)

            // पार्टी वार हिसाब (पुरानी बाकी + नया बिल - भुगतान = कुल बाकी)
            y += 24f
            canvas.drawText("पार्टी वार बकाया सारांश (पुरानी बाकी + नया बिल - जमा = कुल बाकी):", 35f, y, subHeaderPaint)
            y += 18f

            partySummaries.take(12).forEach { summary ->
                val dirText = if (summary.party.direction == HisabDirection.AANA.name) "आना" else "देना"
                val line = "${summary.party.name} (${summary.party.city}) [$dirText] | पुरानी: ${formatInr(summary.oldBalance)} | नया बिल: ${formatInr(summary.newBillTotal)} | जमा: ${formatInr(summary.totalPayments)} | बाकी: ${formatInr(summary.netClosingBalance)}"
                canvas.drawText(line.take(95), 35f, y, bodyPaint)
                y += 16f
            }

            y += 10f
            canvas.drawLine(35f, y, 560f, y, linePaint)
            y += 22f
            canvas.drawText("प्रमुख लेन-देन प्रविष्टियां (तारीख वार):", 35f, y, subHeaderPaint)
            y += 18f

            entries.take(15).forEach { e ->
                val typeLabel = EntryType.entries.find { it.name == e.entryType }?.hindiTitle ?: e.entryType
                val detail = if (e.entryType == EntryType.BIG_ANIMAL.name) {
                    "जानवर: ${e.animalCount}, वजन: ${e.totalWeightKg} KG × ₹${e.ratePerKg}"
                } else {
                    e.itemDescription.ifBlank { e.paymentMode }
                }
                val rowText = "${e.dateString} | ${e.partyName} | $typeLabel ($detail) | रकम: ${formatInr(e.totalAmount)}"
                if (y < 790f) {
                    canvas.drawText(rowText.take(95), 35f, y, bodyPaint)
                    y += 15f
                }
            }

            if (officeEntries.isNotEmpty() && y < 760f) {
                y += 12f
                val given = officeEntries.filter { it.transactionType == "GIVEN" }.sumOf { it.amount }
                val received = officeEntries.filter { it.transactionType == "RECEIVED" }.sumOf { it.amount }
                canvas.drawText(
                    "ऑफिस (अप्सर भाई) सारांश - कुल दिए: ${formatInr(given)} | कुल लिए: ${formatInr(received)} | नेट बैलेंस: ${formatInr(given - received)}",
                    35f,
                    y,
                    subHeaderPaint
                )
            }

            pdfDocument.finishPage(page)

            val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
            val pdfFile = File(reportsDir, "HAWELI_Hisab_Report_${System.currentTimeMillis()}.pdf")
            FileOutputStream(pdfFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()

            shareFile(context, pdfFile, "application/pdf", "HAWELI PDF रिपोर्ट शेयर/डाउनलोड करें")
        } catch (e: Exception) {
            Toast.makeText(context, "PDF बनाने में त्रुटि: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * मासिक एवं पार्टी हिसाब की Excel (.csv UTF-8 with BOM) फाइल बनाकर शेयर/डाउनलोड करता है
     */
    fun exportMonthlyExcelCsvReport(
        context: Context,
        partySummaries: List<PartyBalanceSummary>,
        entries: List<LedgerEntry>,
        officeEntries: List<OfficeEntry>
    ) {
        try {
            val sb = StringBuilder()
            // UTF-8 BOM for proper Hindi rendering in Microsoft Excel
            sb.append('\uFEFF')
            sb.appendLine("HAWELI (हवेली) - संपूर्ण व्यापार हिसाब-किताब (Excel Report)")
            sb.appendLine()
            sb.appendLine("पार्टी का नाम,शहर,प्रकार (आना/देना),पुरानी बाकी (₹),नया बिल (₹),कुल भुगतान/जमा (₹),नेट कुल बाकी (₹)")
            partySummaries.forEach { s ->
                val dir = if (s.party.direction == HisabDirection.AANA.name) "आना" else "देना"
                sb.appendLine(""${s.party.name}","${s.party.city}","$dir",${s.oldBalance},${s.newBillTotal},${s.totalPayments},${s.netClosingBalance}")
            }

            sb.appendLine()
            sb.appendLine("तारीख,पार्टी का नाम,शहर,विभाग,एंट्री प्रकार,जानवर संख्या,कुल वजन (KG),प्रति KG रेट (₹),विवरण/माध्यम,कुल रकम (₹)")
            entries.forEach { e ->
                val dir = if (e.direction == HisabDirection.AANA.name) "आना" else "देना"
                val typeLabel = EntryType.entries.find { it.name == e.entryType }?.hindiTitle ?: e.entryType
                val desc = e.itemDescription.ifBlank { e.paymentMode }.replace(""", "'")
                sb.appendLine(""${e.dateString}","${e.partyName}","${e.city}","$dir","$typeLabel",${e.animalCount},${e.totalWeightKg},${e.ratePerKg},"$desc",${e.totalAmount}")
            }

            sb.appendLine()
            sb.appendLine("ऑफिस हिसाब (अप्सर भाई)")
            sb.appendLine("तारीख,नाम,लेन-देन प्रकार,रकम (₹),विवरण")
            officeEntries.forEach { o ->
                val tLabel = if (o.transactionType == "GIVEN") "पैसे दिए" else "पैसे लिए"
                sb.appendLine(""${o.dateString}","${o.personName}","$tLabel",${o.amount},"${o.remark.replace(""", "'")}"")
            }

            val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
            val csvFile = File(reportsDir, "HAWELI_Hisab_Excel_${System.currentTimeMillis()}.csv")
            FileOutputStream(csvFile).use { out ->
                out.write(sb.toString().toByteArray(Charsets.UTF_8))
            }

            shareFile(context, csvFile, "text/csv", "HAWELI Excel (CSV) रिपोर्ट डाउनलोड/शेयर करें")
        } catch (e: Exception) {
            Toast.makeText(context, "Excel बनाने में त्रुटि: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle))
    }
}
