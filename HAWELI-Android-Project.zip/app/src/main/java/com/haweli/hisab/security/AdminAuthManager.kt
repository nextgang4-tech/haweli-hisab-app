package com.haweli.hisab.security

import java.security.MessageDigest

/**
 * STRICT SECURITY RULE IMPLEMENTATION:
 * 1. कोई भी सामान्य (Normal) यूजर किसी भी एंट्री, पार्टी या पेमेंट को एडिट या डिलीट नहीं कर सकता।
 * 2. एडिट (Edit) और डिलीट (Delete) बटन केवल तभी दिखाई देंगे और काम करेंगे जब यूजर 'Admin' के रूप में लॉगिन हो।
 * 3. Admin Username और Password कभी भी APK के UI या सोर्स कोड में सादे टेक्स्ट (Plaintext) में नहीं दिखेंगे।
 *    यहाँ केवल क्रिप्टोग्राफ़िक SHA-256 हैश मिलान (Hash Verification) का उपयोग किया गया है।
 */
object AdminAuthManager {

    // Salt string for cryptographic verification (no plaintext credentials stored)
    private const val CRYPTO_SALT = "HAWELI_HISAB_2026_SECURE_SALT"

    // Precomputed SHA-256 hashes of salted lowercase username and exact password:
    // sha256("HAWELI_HISAB_2026_SECURE_SALT:user:" + username.trim().lowercase())
    private const val EXPECTED_USER_HASH = "c09671a5eed18016dd1caf68644e9024d408a5575cf8cc544f667ef371d13834"
    // sha256("HAWELI_HISAB_2026_SECURE_SALT:pass:" + password)
    private const val EXPECTED_PASS_HASH = "c7121c4afa6f22a9ff43f8877d645fd0f088d72ab78ccbea470ec7543c5c13fc"

    /**
     * क्रिप्टोग्राफ़िक हैश द्वारा एडमिन लॉगिन की जांच करता है।
     * APK के अंदर कहीं भी यूजरनेम या पासवर्ड सादे अक्षरों में मौजूद नहीं है।
     */
    fun verifyAdminCredentials(inputUsername: String, inputPassword: String): Boolean {
        val normalizedUser = inputUsername.trim().lowercase()
        val userHash = sha256("$CRYPTO_SALT:user:$normalizedUser")
        val passHash = sha256("$CRYPTO_SALT:pass:$inputPassword")
        return constantTimeEquals(userHash, EXPECTED_USER_HASH) &&
               constantTimeEquals(passHash, EXPECTED_PASS_HASH)
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var result = 0
        for (i in a.indices) {
            result = result or (a[i].code xor b[i].code)
        }
        return result == 0
    }
}
