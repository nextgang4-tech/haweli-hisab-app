package com.haweli.hisab.model

/**
 * शहरों की सूची (City-Wise Party Classification)
 */
enum class CityCategory(val hindiName: String) {
    BARAMATI("बारामती"),
    BHOOM("भूम"),
    DHARASHIV("धाराशिव"),
    OTHER("अन्य शहर");

    companion object {
        fun fromHindi(name: String): CityCategory {
            return entries.find { it.hindiName == name || it.name == name } ?: OTHER
        }
    }
}

/**
 * हिसाब का प्रकार: आना (Receivable/Aana) या देना (Payable/Dena)
 */
enum class HisabDirection(val hindiLabel: String) {
    AANA("आना (लेना है)"),
    DENA("देना (देना है)")
}

/**
 * एंट्री की श्रेणी:
 * 1. BIG_ANIMAL: बड़े जानवरों का हिसाब (संख्या, कुल वजन KG, प्रति KG रेट = कुल रकम)
 * 2. VEAL_GOODS: Veal माल का हिसाब
 * 3. PAYMENT: अलग-अलग तारीखों पर भुगतान (Payment) की एंट्री
 * 4. OLD_BALANCE: पुरानी बाकी (Opening / Previous Balance adjustment)
 */
enum class EntryType(val hindiTitle: String) {
    BIG_ANIMAL("बड़े जानवरों का हिसाब"),
    VEAL_GOODS("Veal माल का हिसाब"),
    PAYMENT("भुगतान (Payment) एंट्री"),
    OLD_BALANCE("पुरानी बाकी")
}

/**
 * पार्टी का मॉडल (Party Master)
 */
data class Party(
    val id: String = "",
    val name: String = "",
    val phone: String = "",
    val city: String = CityCategory.BARAMATI.hindiName,
    val direction: String = HisabDirection.AANA.name, // AANA or DENA
    val openingBalance: Double = 0.0, // पुरानी बाकी
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * पार्टी खाते की प्रत्येक एंट्री (Ledger Entry)
 */
data class LedgerEntry(
    val id: String = "",
    val partyId: String = "",
    val partyName: String = "",
    val city: String = "",
    val direction: String = HisabDirection.AANA.name, // AANA or DENA
    val entryType: String = EntryType.BIG_ANIMAL.name,
    val dateString: String = "", // DD-MM-YYYY
    val timestamp: Long = System.currentTimeMillis(),
    // बड़े जानवरों का हिसाब fields
    val animalCount: Int = 0,
    val totalWeightKg: Double = 0.0,
    val ratePerKg: Double = 0.0,
    // Veal माल का हिसाब / विवरण
    val itemDescription: String = "",
    // कुल रकम (Bill amount or Payment amount)
    val totalAmount: Double = 0.0,
    val paymentMode: String = "नकद (Cash)", // नकद, बैंक/UPI, चेक
    val notes: String = ""
) {
    val isPayment: Boolean
        get() = entryType == EntryType.PAYMENT.name
}

/**
 * ऑफिस सेक्शन (अप्सर भाई) का हिसाब मॉडल
 */
data class OfficeEntry(
    val id: String = "",
    val personName: String = "अप्सर भाई (ऑफिस)",
    val transactionType: String = "GIVEN", // GIVEN (पैसे दिए) or RECEIVED (पैसे लिए)
    val amount: Double = 0.0,
    val dateString: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val remark: String = ""
)

/**
 * पार्टी के कुल हिसाब का सारांश (Calculated Summary)
 */
data class PartyBalanceSummary(
    val party: Party,
    val oldBalance: Double,
    val newBillTotal: Double,
    val totalPayments: Double,
    val netClosingBalance: Double // (oldBalance + newBillTotal) - totalPayments
)
