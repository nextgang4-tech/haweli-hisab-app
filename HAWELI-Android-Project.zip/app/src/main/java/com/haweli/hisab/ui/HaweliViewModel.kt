package com.haweli.hisab.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.haweli.hisab.data.HaweliRepository
import com.haweli.hisab.model.*
import com.haweli.hisab.security.AdminAuthManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class HaweliViewModel(application: Application) : AndroidViewModel(application) {

    val repository = HaweliRepository(application.applicationContext)

    val parties = repository.parties
    val ledgerEntries = repository.ledgerEntries
    val officeEntries = repository.officeEntries
    val isFirebaseLocked = repository.isFirebaseLocked
    val isCloudConnected = repository.isCloudConnected

    // Admin Role State (Default false = Normal User; Edit & Delete buttons are completely hidden)
    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    private val _selectedCityFilter = MutableStateFlow("सभी शहर")
    val selectedCityFilter: StateFlow<String> = _selectedCityFilter.asStateFlow()

    fun setCityFilter(city: String) {
        _selectedCityFilter.value = city
    }

    /**
     * एडमिन लॉगिन सत्यापन (SHA-256 Hash Comparison के माध्यम से)
     */
    fun loginAsAdmin(username: String, password: String): Boolean {
        val success = AdminAuthManager.verifyAdminCredentials(username, password)
        if (success) {
            _isAdminLoggedIn.value = true
        }
        return success
    }

    fun logoutAdmin() {
        _isAdminLoggedIn.value = false
    }

    /**
     * किसी पार्टी का पूरा बकाया हिसाब (पुरानी बाकी + नया बिल - कुल भुगतान = नेट बाकी)
     */
    fun computePartySummary(party: Party, allEntries: List<LedgerEntry>): PartyBalanceSummary {
        val partyEntries = allEntries.filter { it.partyId == party.id }
        val extraOldBalance = partyEntries
            .filter { it.entryType == EntryType.OLD_BALANCE.name }
            .sumOf { it.totalAmount }
        val totalOldBalance = party.openingBalance + extraOldBalance

        val newBills = partyEntries
            .filter { it.entryType == EntryType.BIG_ANIMAL.name || it.entryType == EntryType.VEAL_GOODS.name }
            .sumOf { it.totalAmount }

        val payments = partyEntries
            .filter { it.entryType == EntryType.PAYMENT.name }
            .sumOf { it.totalAmount }

        val netBalance = (totalOldBalance + newBills) - payments
        return PartyBalanceSummary(
            party = party,
            oldBalance = totalOldBalance,
            newBillTotal = newBills,
            totalPayments = payments,
            netClosingBalance = netBalance
        )
    }

    /**
     * सभी पार्टियों का सारांश
     */
    fun computeAllPartySummaries(
        partyList: List<Party>,
        entryList: List<LedgerEntry>
    ): List<PartyBalanceSummary> {
        return partyList.map { computePartySummary(it, entryList) }
    }
}
