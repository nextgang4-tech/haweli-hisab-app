package com.haweli.hisab.data

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.PersistentCacheSettings
import com.haweli.hisab.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Firebase Firestore + Local Offline Cache Repository
 * - जब इंटरनेट चालू हो तो Firebase Firestore के माध्यम से सभी मोबाइलों पर तुरंत Real-Time Sync करता है।
 * - इंटरनेट न होने पर डेटा लोकल कैश (Offline Persistence + Local Backup) में सुरक्षित रखता है और ऑनलाइन आने पर सिंक करता है।
 */
class HaweliRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("haweli_local_cache", Context.MODE_PRIVATE)

    private var firestore: FirebaseFirestore? = null
    private var partiesListener: ListenerRegistration? = null
    private var entriesListener: ListenerRegistration? = null
    private var officeListener: ListenerRegistration? = null
    private var lockListener: ListenerRegistration? = null

    private val _parties = MutableStateFlow<List<Party>>(emptyList())
    val parties: StateFlow<List<Party>> = _parties.asStateFlow()

    private val _ledgerEntries = MutableStateFlow<List<LedgerEntry>>(emptyList())
    val ledgerEntries: StateFlow<List<LedgerEntry>> = _ledgerEntries.asStateFlow()

    private val _officeEntries = MutableStateFlow<List<OfficeEntry>>(emptyList())
    val officeEntries: StateFlow<List<OfficeEntry>> = _officeEntries.asStateFlow()

    private val _isFirebaseLocked = MutableStateFlow(false)
    val isFirebaseLocked: StateFlow<Boolean> = _isFirebaseLocked.asStateFlow()

    private val _isCloudConnected = MutableStateFlow(false)
    val isCloudConnected: StateFlow<Boolean> = _isCloudConnected.asStateFlow()

    init {
        loadFromLocalBackup()
        initializeFirebase(context)
    }

    private fun initializeFirebase(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            val db = FirebaseFirestore.getInstance()
            val settings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(
                    PersistentCacheSettings.newBuilder()
                        .setSizeBytes(100L * 1024L * 1024L) // 100 MB offline cache
                        .build()
                )
                .build()
            db.firestoreSettings = settings
            firestore = db
            startRealtimeListeners(db)
        } catch (e: Exception) {
            _isCloudConnected.value = false
        }
    }

    private fun startRealtimeListeners(db: FirebaseFirestore) {
        try {
            partiesListener = db.collection("parties")
                .addSnapshotListener { snapshot, error ->
                    if (error == null && snapshot != null) {
                        _isCloudConnected.value = true
                        val list = snapshot.documents.mapNotNull { doc ->
                            Party(
                                id = doc.id,
                                name = doc.getString("name") ?: "",
                                phone = doc.getString("phone") ?: "",
                                city = doc.getString("city") ?: CityCategory.BARAMATI.hindiName,
                                direction = doc.getString("direction") ?: HisabDirection.AANA.name,
                                openingBalance = doc.getDouble("openingBalance") ?: 0.0,
                                createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                            )
                        }.sortedBy { it.name }
                        if (list.isNotEmpty() || _parties.value.isEmpty()) {
                            _parties.value = list
                            saveToLocalBackup()
                        }
                    }
                }

            entriesListener = db.collection("ledger_entries")
                .addSnapshotListener { snapshot, error ->
                    if (error == null && snapshot != null) {
                        val list = snapshot.documents.mapNotNull { doc ->
                            LedgerEntry(
                                id = doc.id,
                                partyId = doc.getString("partyId") ?: "",
                                partyName = doc.getString("partyName") ?: "",
                                city = doc.getString("city") ?: "",
                                direction = doc.getString("direction") ?: HisabDirection.AANA.name,
                                entryType = doc.getString("entryType") ?: EntryType.BIG_ANIMAL.name,
                                dateString = doc.getString("dateString") ?: todayDateString(),
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                animalCount = (doc.getLong("animalCount") ?: 0L).toInt(),
                                totalWeightKg = doc.getDouble("totalWeightKg") ?: 0.0,
                                ratePerKg = doc.getDouble("ratePerKg") ?: 0.0,
                                itemDescription = doc.getString("itemDescription") ?: "",
                                totalAmount = doc.getDouble("totalAmount") ?: 0.0,
                                paymentMode = doc.getString("paymentMode") ?: "नकद (Cash)",
                                notes = doc.getString("notes") ?: ""
                            )
                        }.sortedByDescending { it.timestamp }
                        if (list.isNotEmpty() || _ledgerEntries.value.isEmpty()) {
                            _ledgerEntries.value = list
                            saveToLocalBackup()
                        }
                    }
                }

            officeListener = db.collection("office_entries")
                .addSnapshotListener { snapshot, error ->
                    if (error == null && snapshot != null) {
                        val list = snapshot.documents.mapNotNull { doc ->
                            OfficeEntry(
                                id = doc.id,
                                personName = doc.getString("personName") ?: "अप्सर भाई (ऑफिस)",
                                transactionType = doc.getString("transactionType") ?: "GIVEN",
                                amount = doc.getDouble("amount") ?: 0.0,
                                dateString = doc.getString("dateString") ?: todayDateString(),
                                timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                                remark = doc.getString("remark") ?: ""
                            )
                        }.sortedByDescending { it.timestamp }
                        if (list.isNotEmpty() || _officeEntries.value.isEmpty()) {
                            _officeEntries.value = list
                            saveToLocalBackup()
                        }
                    }
                }

            lockListener = db.collection("app_config").document("settings_lock")
                .addSnapshotListener { snapshot, error ->
                    if (error == null && snapshot != null && snapshot.exists()) {
                        val locked = snapshot.getBoolean("isLocked") ?: false
                        _isFirebaseLocked.value = locked
                        prefs.edit().putBoolean("is_firebase_locked", locked).apply()
                    }
                }
        } catch (_: Exception) {
            // Works seamlessly with local backup cache when offline
        }
    }

    // ==================== CRUD OPERATIONS ====================
    // Note: Edit & Delete operations require `isAdmin == true` enforced in ViewModel & UI & Firestore Rules

    fun addOrUpdateParty(party: Party, isAdmin: Boolean): Boolean {
        val isNew = party.id.isBlank()
        if (!isNew && !isAdmin) return false // केवल एडमिन ही पार्टी एडिट कर सकता है

        val finalParty = if (isNew) party.copy(id = UUID.randomUUID().toString()) else party
        val updatedList = _parties.value.filterNot { it.id == finalParty.id } + finalParty
        _parties.value = updatedList.sortedBy { it.name }
        saveToLocalBackup()

        firestore?.collection("parties")?.document(finalParty.id)?.set(
            mapOf(
                "name" to finalParty.name,
                "phone" to finalParty.phone,
                "city" to finalParty.city,
                "direction" to finalParty.direction,
                "openingBalance" to finalParty.openingBalance,
                "createdAt" to finalParty.createdAt
            )
        )
        return true
    }

    fun deleteParty(partyId: String, isAdmin: Boolean): Boolean {
        if (!isAdmin) return false // सामान्य यूजर पार्टी डिलीट नहीं कर सकता
        _parties.value = _parties.value.filterNot { it.id == partyId }
        _ledgerEntries.value = _ledgerEntries.value.filterNot { it.partyId == partyId }
        saveToLocalBackup()

        firestore?.collection("parties")?.document(partyId)?.delete()
        return true
    }

    fun addOrUpdateLedgerEntry(entry: LedgerEntry, isAdmin: Boolean): Boolean {
        val isNew = entry.id.isBlank()
        if (!isNew && !isAdmin) return false // सामान्य यूजर एंट्री एडिट नहीं कर सकता

        // बड़े जानवरों का हिसाब: कुल वजन KG × प्रति KG रेट = कुल रकम (स्वचालित गणना)
        val calculatedAmount = if (entry.entryType == EntryType.BIG_ANIMAL.name && entry.totalWeightKg > 0 && entry.ratePerKg > 0) {
            entry.totalWeightKg * entry.ratePerKg
        } else {
            entry.totalAmount
        }

        val finalEntry = (if (isNew) entry.copy(id = UUID.randomUUID().toString()) else entry)
            .copy(totalAmount = calculatedAmount)

        val updatedList = _ledgerEntries.value.filterNot { it.id == finalEntry.id } + finalEntry
        _ledgerEntries.value = updatedList.sortedByDescending { it.timestamp }
        saveToLocalBackup()

        firestore?.collection("ledger_entries")?.document(finalEntry.id)?.set(
            mapOf(
                "partyId" to finalEntry.partyId,
                "partyName" to finalEntry.partyName,
                "city" to finalEntry.city,
                "direction" to finalEntry.direction,
                "entryType" to finalEntry.entryType,
                "dateString" to finalEntry.dateString,
                "timestamp" to finalEntry.timestamp,
                "animalCount" to finalEntry.animalCount,
                "totalWeightKg" to finalEntry.totalWeightKg,
                "ratePerKg" to finalEntry.ratePerKg,
                "itemDescription" to finalEntry.itemDescription,
                "totalAmount" to finalEntry.totalAmount,
                "paymentMode" to finalEntry.paymentMode,
                "notes" to finalEntry.notes
            )
        )
        return true
    }

    fun deleteLedgerEntry(entryId: String, isAdmin: Boolean): Boolean {
        if (!isAdmin) return false // केवल एडमिन डिलीट कर सकता है
        _ledgerEntries.value = _ledgerEntries.value.filterNot { it.id == entryId }
        saveToLocalBackup()

        firestore?.collection("ledger_entries")?.document(entryId)?.delete()
        return true
    }

    fun addOrUpdateOfficeEntry(entry: OfficeEntry, isAdmin: Boolean): Boolean {
        val isNew = entry.id.isBlank()
        if (!isNew && !isAdmin) return false // केवल एडमिन ऑफिस एंट्री एडिट कर सकता है

        val finalEntry = if (isNew) entry.copy(id = UUID.randomUUID().toString()) else entry
        val updatedList = _officeEntries.value.filterNot { it.id == finalEntry.id } + finalEntry
        _officeEntries.value = updatedList.sortedByDescending { it.timestamp }
        saveToLocalBackup()

        firestore?.collection("office_entries")?.document(finalEntry.id)?.set(
            mapOf(
                "personName" to finalEntry.personName,
                "transactionType" to finalEntry.transactionType,
                "amount" to finalEntry.amount,
                "dateString" to finalEntry.dateString,
                "timestamp" to finalEntry.timestamp,
                "remark" to finalEntry.remark
            )
        )
        return true
    }

    fun deleteOfficeEntry(entryId: String, isAdmin: Boolean): Boolean {
        if (!isAdmin) return false // केवल एडमिन डिलीट कर सकता है
        _officeEntries.value = _officeEntries.value.filterNot { it.id == entryId }
        saveToLocalBackup()

        firestore?.collection("office_entries")?.document(entryId)?.delete()
        return true
    }

    fun setFirebaseLock(locked: Boolean, isAdmin: Boolean): Boolean {
        if (!isAdmin) return false
        _isFirebaseLocked.value = locked
        prefs.edit().putBoolean("is_firebase_locked", locked).apply()
        firestore?.collection("app_config")?.document("settings_lock")?.set(
            mapOf("isLocked" to locked, "updatedAt" to System.currentTimeMillis())
        )
        return true
    }

    // ==================== LOCAL OFFLINE PERSISTENCE ====================

    private fun saveToLocalBackup() {
        val partiesArray = JSONArray()
        _parties.value.forEach { p ->
            partiesArray.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("phone", p.phone)
                put("city", p.city)
                put("direction", p.direction)
                put("openingBalance", p.openingBalance)
                put("createdAt", p.createdAt)
            })
        }

        val entriesArray = JSONArray()
        _ledgerEntries.value.forEach { e ->
            entriesArray.put(JSONObject().apply {
                put("id", e.id)
                put("partyId", e.partyId)
                put("partyName", e.partyName)
                put("city", e.city)
                put("direction", e.direction)
                put("entryType", e.entryType)
                put("dateString", e.dateString)
                put("timestamp", e.timestamp)
                put("animalCount", e.animalCount)
                put("totalWeightKg", e.totalWeightKg)
                put("ratePerKg", e.ratePerKg)
                put("itemDescription", e.itemDescription)
                put("totalAmount", e.totalAmount)
                put("paymentMode", e.paymentMode)
                put("notes", e.notes)
            })
        }

        val officeArray = JSONArray()
        _officeEntries.value.forEach { o ->
            officeArray.put(JSONObject().apply {
                put("id", o.id)
                put("personName", o.personName)
                put("transactionType", o.transactionType)
                put("amount", o.amount)
                put("dateString", o.dateString)
                put("timestamp", o.timestamp)
                put("remark", o.remark)
            })
        }

        prefs.edit()
            .putString("parties_json", partiesArray.toString())
            .putString("entries_json", entriesArray.toString())
            .putString("office_json", officeArray.toString())
            .apply()
    }

    private fun loadFromLocalBackup() {
        _isFirebaseLocked.value = prefs.getBoolean("is_firebase_locked", false)

        val partiesStr = prefs.getString("parties_json", null)
        if (!partiesStr.isNullOrBlank()) {
            val arr = JSONArray(partiesStr)
            val list = mutableListOf<Party>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Party(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        phone = o.optString("phone"),
                        city = o.optString("city", CityCategory.BARAMATI.hindiName),
                        direction = o.optString("direction", HisabDirection.AANA.name),
                        openingBalance = o.optDouble("openingBalance", 0.0),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
            _parties.value = list
        }

        val entriesStr = prefs.getString("entries_json", null)
        if (!entriesStr.isNullOrBlank()) {
            val arr = JSONArray(entriesStr)
            val list = mutableListOf<LedgerEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    LedgerEntry(
                        id = o.optString("id"),
                        partyId = o.optString("partyId"),
                        partyName = o.optString("partyName"),
                        city = o.optString("city"),
                        direction = o.optString("direction", HisabDirection.AANA.name),
                        entryType = o.optString("entryType", EntryType.BIG_ANIMAL.name),
                        dateString = o.optString("dateString", todayDateString()),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis()),
                        animalCount = o.optInt("animalCount", 0),
                        totalWeightKg = o.optDouble("totalWeightKg", 0.0),
                        ratePerKg = o.optDouble("ratePerKg", 0.0),
                        itemDescription = o.optString("itemDescription"),
                        totalAmount = o.optDouble("totalAmount", 0.0),
                        paymentMode = o.optString("paymentMode", "नकद (Cash)"),
                        notes = o.optString("notes")
                    )
                )
            }
            _ledgerEntries.value = list
        }

        val officeStr = prefs.getString("office_json", null)
        if (!officeStr.isNullOrBlank()) {
            val arr = JSONArray(officeStr)
            val list = mutableListOf<OfficeEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    OfficeEntry(
                        id = o.optString("id"),
                        personName = o.optString("personName", "अप्सर भाई (ऑफिस)"),
                        transactionType = o.optString("transactionType", "GIVEN"),
                        amount = o.optDouble("amount", 0.0),
                        dateString = o.optString("dateString", todayDateString()),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis()),
                        remark = o.optString("remark")
                    )
                )
            }
            _officeEntries.value = list
        }
    }

    companion object {
        fun todayDateString(): String {
            return SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
        }
    }
}
