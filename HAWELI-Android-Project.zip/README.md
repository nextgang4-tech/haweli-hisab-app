# HAWELI (हवेली) – संपूर्ण व्यापार हिसाब-किताब Android App & GitHub Source Code

यह प्रोजेक्ट **HAWELI (`com.haweli.hisab`)** Android एप्लीकेशन का पूर्ण, प्रोडक्शन-रेडी सोर्स कोड है। इसमें आपके सभी सुरक्षा नियमों (Strict Security Rules), शुद्ध हिंदी इंटरफेस, क्लीन डैशबोर्ड और Firebase Real-Time Sync को पूरी तरह से लागू किया गया है।

## 1. प्रमुख नियम एवं फीचर्स जो इस कोड में लागू हैं

| मॉड्यूल / नियम | कार्यान्वयन विवरण (Implementation Details) |
| :--- | :--- |
| **क्लीन हेडर डैशबोर्ड (Clean Header)** | ऐप खोलते ही होमपेज के हेडर में केवल दो बड़े मुख्य कार्ड दिखाई देते हैं: **1. कुल आना (Aana)** और **2. कुल देना (Dena)**। अन्य सभी सेक्शन नीचे नेविगेशन बार में रखे गए हैं। |
| **एडमिन Edit/Delete सुरक्षा नियम** | सामान्य (Normal) यूजर को ऐप में कहीं भी **Edit** या **Delete** बटन दिखाई नहीं देते। केवल एडमिन लॉगिन करने पर ही ये बटन दिखते और काम करते हैं। |
| **गोपनीय एडमिन क्रेडेंशियल्स** | एडमिन यूज़रनेम और पासवर्ड को `AdminAuthManager.kt` में **Salted SHA-256 Cryptographic Hash** के रूप में सत्यापित किया गया है, ताकि APK या UI में कहीं भी सादे अक्षरों (Plaintext) में यूज़रनेम/पासवर्ड दिखाई न दे। |
| **शहर के अनुसार पार्टियां** | **बारामती, भूम, धाराशिव, और अन्य शहर** के अनुसार पार्टियों का वर्गीकरण और फ़िल्टर। |
| **बड़े जानवर, Veal माल और पेमेंट** | बड़े जानवरों के हिसाब में `संख्या`, `कुल वजन (KG) × प्रति KG रेट = कुल रकम` की ऑटोमैटिक गणना, `Veal माल` का हिसाब, और अलग-अलग तारीखों पर `Payment` की एंट्री। |
| **ऑफिस सेक्शन (अप्सर भाई)** | अप्सर भाई के लिए `पैसे दिए` और `पैसे लिए` का पूरा खाता और ऑटोमैटिक नेट बैलेंस कैलकुलेशन। |
| **मासिक रिपोर्ट (PDF व Excel)** | तारीख/महीने के अनुसार फ़िल्टर, `पुरानी बाकी + नया बिल - भुगतान = कुल बाकी` का हिसाब, और एक क्लिक में **PDF** तथा **Excel (CSV)** में डाउनलोड करने की सुविधा। |
| **Firebase Real-Time Sync व Offline Cache** | `PersistentCacheSettings` (100 MB लोकल कैश) और `SharedPreferences` बैकअप के साथ इंटरनेट न होने पर डेटा मोबाइल में सेव होता है और ऑनलाइन आते ही दूसरे मोबाइल पर तुरंत सिंक हो जाता है। |

## 2. प्रोजेक्ट स्ट्रक्चर (Android Studio & Gradle Compatible)

```text
HAWELI-Android-Project/
├── .github/workflows/
│   └── build-apk.yml                # GitHub Actions से अपने-आप APK बनाने की वर्कफ़्लो फ़ाइल
├── app/
│   ├── build.gradle.kts             # ऐप मॉड्यूल Gradle और Firebase/Compose डिपेंडेंसी
│   ├── google-services.json         # Firebase कॉन्फ़िगरेशन फ़ाइल
│   ├── proguard-rules.pro           # R8/ProGuard नियम
│   └── src/main/
│       ├── AndroidManifest.xml      # पैकेज com.haweli.hisab और FileProvider सेटअप
│       ├── java/com/haweli/hisab/
│       │   ├── MainActivity.kt              # मुख्य हिंदी UI, क्लीन डैशबोर्ड, पार्टी, ऑफिस और रिपोर्ट स्क्रीन
│       │   ├── model/Models.kt              # Party, LedgerEntry, OfficeEntry डेटा मॉडल
│       │   ├── security/AdminAuthManager.kt # SHA-256 गुप्त एडमिन प्रमाणीकरण (बिना Plaintext पासवर्ड)
│       │   ├── data/HaweliRepository.kt     # Firebase Firestore Real-Time Sync + Offline Cache
│       │   ├── ui/HaweliViewModel.kt        # स्टेट मैनेजमेंट और बकाया गणना
│       │   └── util/ReportExporter.kt       # PDF और Excel (.csv) जनरेटर
│       └── res/
│           ├── drawable/            # ऐप आइकॉन वेक्टर
│           ├── mipmap-anydpi-v26/   # लॉन्चर आइकॉन
│           ├── values/strings.xml   # शुद्ध हिंदी स्ट्रिंग्स
│           ├── values/themes.xml    # Material थीम
│           └── xml/file_paths.xml   # PDF/Excel शेयरिंग पथ
├── firestore.rules                  # Firebase Firestore बैकएंड सुरक्षा नियम (Admin-Only Edit/Delete)
├── build.gradle.kts                 # रूट Gradle फ़ाइल
├── settings.gradle.kts              # प्रोजेक्ट सेटिंग्स
└── gradle.properties                # JVM व AndroidX प्रॉपर्टीज
```

## 3. GitHub से सीधे Installable APK कैसे बनाएं (Step-by-Step)

1. **GitHub पर नया Repository बनाएं**:
   - अपने GitHub अकाउंट पर जाकर `HAWELI-Hisab-App` नाम से एक नया (Private या Public) रिपॉजिटरी बनाएं।
2. **सोर्स कोड अपलोड करें**:
   - दिए गए `HAWELI-Android-Project.zip` को अनज़िप (Extract) करें और उसकी सारी फाइलें (`.github/workflows/build-apk.yml`, `app/`, `build.gradle.kts`, `settings.gradle.kts` आदि) अपने GitHub रिपॉजिटरी में अपलोड (Push) कर दें।
3. **GitHub Actions से अपने-आप APK तैयार करें**:
   - जैसे ही आप कोड Push करेंगे, GitHub पर ऊपर **Actions** टैब में जाएं।
   - वहां **"Build HAWELI Android APK"** वर्कफ़्लो अपने-आप चलेगा (या आप **Run workflow** बटन दबाकर भी चला सकते हैं)।
   - लगभग 2–3 मिनट में बिल्ड पूरा होने पर नीचे **Artifacts** सेक्शन में **`HAWELI-Installable-APK`** दिखाई देगा। उस पर क्लिक करके अपना `app-debug.apk` डाउनलोड करें और मोबाइल में इंस्टॉल करें।

## 4. Firebase Real-Time Sync सेटअप गाइड

1. [Firebase Console](https://console.firebase.google.com/) पर जाएं और **Add Project** पर क्लिक करके `haweli-hisab` नाम से प्रोजेक्ट बनाएं।
2. **Android App रजिस्टर करें**:
   - Android आइकॉन पर क्लिक करें और पैकेज नाम **`com.haweli.hisab`** दर्ज करें।
   - वहां से अपनी असली `google-services.json` फाइल डाउनलोड करें और प्रोजेक्ट के `app/google-services.json` की जगह रख दें (या GitHub रिपॉजिटरी के `Settings -> Secrets and variables -> Actions` में `GOOGLE_SERVICES_JSON` नाम से Secret बनाकर उसमें पेस्ट कर दें)।
3. **Cloud Firestore चालू करें**:
   - बाएं मेनू से **Build -> Firestore Database -> Create database** पर क्लिक करें।
   - **Rules** टैब में जाकर इस प्रोजेक्ट की `firestore.rules` फाइल के नियम पेस्ट करके **Publish** कर दें।
